import { Injectable } from '@angular/core';
//import {HttpClient} from '@angular/http';
import {  Http,  Headers,  RequestOptions,  Response} from '@angular/http';
import { GlobalServiceService } from './global-service.service';
import {  Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map'


@Injectable()
export class FetchDataService {

  constructor(private http: Http,private gs:GlobalServiceService) { }

 createAuthorizationHeader(headers: Headers) {
    const token = localStorage.getItem('authToken');
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Authorization', 'Bearer 7SXBncr_mGig6oCE9XoRBG1J1ppMRVY2JLuo-bFF_msSkB4a6VweV8BmmEF4gJJ8s-nkWBvAQD7HAaZMsJ4YTD9zs3Soz0F6-WXa-3z0cPHwRXkwFKhRG9fNnt58OLffKiF2RNg9yA1DN9NEdC6Tzy1fBwrE8ExpqCaM13oU6xZF_x64BG_c-tJzTZ4sge2fT0C0z8WhRI1UwpvI-yw_VkQq-XHSRXGTvOZ3jqlmdf2jQLVaGRQOy3btPEa4cRA6ABsKfu-KL0O32WN84ktp2XtaBl5w0EiXFLm7E8nZNB51X2zjmL3fCNSvn5_jkxt1oruYflcWT93XdnKPIUln4NM4gFOv_TFoF00pk6xJVsg1a4cxAeKE-ijpOoBw9iNKO297C8Q3O2n3BD9LG2AdlQ');
  }

writeHeaders(){
  const headers = new Headers();
 this.createAuthorizationHeader(headers);
 const options = new RequestOptions({headers: headers});
 return options;
}
   
// Method for inserting the value in CASPIO
insertINTOCaspio(user:any){
//let body = 'user_name='+user.userName+'&password='+user.password+'&degination='+user.designation;
const options=this.writeHeaders();
return this.http.post(this.gs.baseUrl+'/rest/v1/tables/user_Login_Table/rows',user,options)
.map((res:Response)=>{res.json();})
}
//END Section--


// Method for inserting the value in CASPIO
getUsetFromCaspio(){
  let userGetQuery='?q={"select:"}';
const options=this.writeHeaders();
    return this.http.get(this.gs.baseUrl+'/rest/v1/tables/user_Login_Table/rows',options)
    .map((res:Response)=>{ return res.json();}) 
}
 //END Section--


 //Method for inserting the value in CASPIO
  deleteUserFromCaspio(username:any) {
    let query='?q={"where":"user_name="'+username+'""}';
   const options=this.writeHeaders();
	 return this.http.delete('/rest/v1/tables/user_Login_Table/rows/'+query,options)
	 	.map((response: Response) => {
	 	response.json();
	 	})
	 	.catch((error:any) => { 
	 		return Observable.throw(error);
	 	});
  }
 // END Section

}
