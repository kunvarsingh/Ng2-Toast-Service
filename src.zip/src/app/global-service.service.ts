import { Injectable } from '@angular/core';

@Injectable()
export class GlobalServiceService {
 sep='kunvar';
 version: string="22.2.2"; 
 baseUrl: string="https://c0abh551.caspio.com";
  constructor() { }

}
