import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import  {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { GlobalServiceService } from './global-service.service';

import  {routing} from './app.routing.config';
import {HttpModule} from '@angular/http';
import { Http,  Headers,  RequestOptions,  Response} from '@angular/http';

import {FetchDataService} from './fetch-data.service';
import { TableComponent } from './Table/table/table.component';
 

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    TableComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    routing,
    FormsModule,
    HttpModule
  ],
  providers: [FetchDataService,GlobalServiceService],
  bootstrap: [AppComponent]
})

export class AppModule {
 }
