export class user{
user_Name : string;
	password: string;
	degination :string;
}
